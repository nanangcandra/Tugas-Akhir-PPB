package com.example.resepmakanan;

public class NasiGoreng {
}
