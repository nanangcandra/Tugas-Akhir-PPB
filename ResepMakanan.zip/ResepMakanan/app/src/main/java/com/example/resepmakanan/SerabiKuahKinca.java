package com.example.resepmakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SerabiKuahKinca extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_serabi_kuah_kinca);
    }
}