package com.example.resepmakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
 Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login= (Button)findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                Intent pindahmenu1 = new Intent(MainActivity.this,MenuUtama.class);
                startActivity(pindahmenu1);
            }
        });
    }
}